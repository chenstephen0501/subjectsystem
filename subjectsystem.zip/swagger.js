const swaggerAutogen = require('swagger-autogen')()

const doc = {
  info: {
    "version": "1.0.0",
    "title": "Subject System REST API",
    "description": ""
  },
  host: "subjectsystem.first-aws-project.com",
  basePath: "/",
  schemes: ['http', 'https'],
  consumes: [],
  produces: [],
  tags: [
    {
      name: "Teacher",
      description: "everything about teachers",
      externalDocs: {
        description: "Find out more",
        url: "subjectsystem.first-aws-project.com"
      }
    },
    {
      name: "Student",
      description: "everything about students",
      externalDocs: {
        description: "Find out more",
        url: "subjectsystem.first-aws-project.com"
      }
    },
    {
      name: "Department",
      description: "everything about departments",
      externalDocs: {
        description: "Find out more",
        url: "subjectsystem.first-aws-project.com"
      }
    },
    {
      name: "Course",
      description: "everything about courses",
      externalDocs: {
        description: "Find out more",
        url: "subjectsystem.first-aws-project.com"
      }
    },
    {
      name: "StudentCourse",
      description: "everything about studentcourses"
    },
    {
      name: "Home",
      description: "Hello World"
    }
  ],
  securityDefinitions: {},
  definitions: {}
}

const outFile = './swagger_output.json'
const endpointFiles = ['./app.js']

swaggerAutogen(outFile, endpointFiles, doc)