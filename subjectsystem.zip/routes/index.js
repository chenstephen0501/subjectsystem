const apis = require('./apis')

module.exports = { apis }